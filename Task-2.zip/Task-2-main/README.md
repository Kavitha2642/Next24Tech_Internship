The task is to develop a Plant Leaf Disease Detection System utilizing AI algorithms. This project is crucial for agricultural sustainability, as it enables early detection and intervention against plant diseases, thereby improving crop yield and quality. 
For this task to execute : data collection, model training, and the development of a user-friendly interface for farmers to utilize this system effectively has been developed.
The ui folder gives an idea of how the baackground and the interface looks like. 
