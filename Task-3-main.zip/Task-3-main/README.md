This task is on the summer heat waves mobile alert system. With climate change exacerbating heat-related risks, this system aims to provide timely alerts to the public, helping them stay safe during extreme heat events. 
This includes data analysis, developing predictive models, and integrating the system with mobile platforms for widespread dissemination of alerts.
The csv file uploaded has the data of historical temperatures recorded and the code for the same is developed.
